import React from "react";
import OrderAll from "../item/OrderAll";

const All = () => {
  return (
    <div>
      All
      <OrderAll />
    </div>
  );
};

export default All;
