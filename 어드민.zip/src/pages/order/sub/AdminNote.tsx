import React from "react";

const AdminNote = () => {
  return <div>AdminNote</div>;
};

export default AdminNote;
