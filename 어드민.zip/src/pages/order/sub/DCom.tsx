import React from "react";

const DCom = () => {
  return <div>DCom</div>;
};

export default DCom;
