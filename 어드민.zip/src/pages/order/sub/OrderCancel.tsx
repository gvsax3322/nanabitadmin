import React from "react";

const OrderCancel = () => {
  return <div>OrderCancel</div>;
};

export default OrderCancel;
