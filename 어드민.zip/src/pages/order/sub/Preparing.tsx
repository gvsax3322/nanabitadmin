import React from "react";

const Preparing = () => {
  return <div>Preparing</div>;
};

export default Preparing;
