import React from "react";

const OrderReturn = () => {
  return <div>OrderReturn</div>;
};

export default OrderReturn;
