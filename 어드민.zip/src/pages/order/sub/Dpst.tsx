import React from "react";
import OrderAll from "../item/OrderAll";

const Dpst = () => {
  return (
    <div>
      Dpst
      <OrderAll />
    </div>
  );
};

export default Dpst;
