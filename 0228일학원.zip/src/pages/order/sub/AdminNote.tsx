import React from "react";
import NoteHeader from "../item/NoteHeader";

const AdminNote = () => {
  return (
    <div>
      AdminNote
      <NoteHeader />
    </div>
  );
};

export default AdminNote;
