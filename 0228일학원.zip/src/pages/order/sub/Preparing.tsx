import React from "react";
import PreparHeader from "../item/PreparHeader";

const Preparing = () => {
  return (
    <div>
      Preparing
      <PreparHeader />
    </div>
  );
};

export default Preparing;
