import React from 'react'

const Qa = () => {
  return (
    <div>qa</div>
  )
}

export default Qa